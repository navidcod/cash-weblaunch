<?php

// If uninstall not called from WordPress, then exit.
defined('WP_UNINSTALL_PLUGIN') or die();

delete_transient('drag_notice_dragonizer_about');
