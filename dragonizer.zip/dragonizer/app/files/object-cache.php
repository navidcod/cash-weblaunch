<?php

/*
    Plugin Name:        %DRAGONIZER_OBJ_NAME%
    Plugin URI:         https://www.rtl-theme.com/dragonizer-wordpress-plugin
	Description:        %DRAGONIZER_OBJ_DESCRIPTION%
    Version:            1.0.0
    Author:             %DRAGONIZER_AUTHOR%
    Author URI:         https://www.rtl-theme.com/author/mahyardyn
    License:            GPLv3
    License URI:        http://www.gnu.org/licenses/gpl-3.0.html
*/

// If this file is called directly, abort.
defined('ABSPATH') or die('No script kiddies please!');

// Just if WordPress is not upgrading
if (!defined('WP_INSTALLING') || !WP_INSTALLING) {

	defined('DRAGONIZER_DIR') ||
		define('DRAGONIZER_DIR', (defined('WP_PLUGIN_DIR') ? WP_PLUGIN_DIR : WP_CONTENT_DIR . '/plugins') . '/dragonizer');

	if (!is_dir(DRAGONIZER_DIR) || !file_exists(DRAGONIZER_DIR . '/app/class-dragonizer-object-cache.php')) {
		if (defined('WP_ADMIN')) {
			add_action(is_network_admin() ? 'network_admin_notices' : 'admin_notices', function () {
				echo '<div class="notice notice-error"><p><strong>Dragonizer Notice:</strong> Some files appear to be missing or out of place. Please re-install Dragonizer or remove <strong>' . esc_html(__FILE__) . '</strong>.</p></div>';
			});
		} else {
			include_once ABSPATH . WPINC . '/cache.php';
		}
	} else {

		!defined('%DRAGONIZER_OBJ_CONST%')
			&& define('%DRAGONIZER_CONST%', true);

		include_once(DRAGONIZER_DIR . '/app/class-dragonizer-object-cache.php');

		if (!class_exists('WP_Object_Cache')) {
			wp_using_ext_object_cache(false);
		}
	}
}
