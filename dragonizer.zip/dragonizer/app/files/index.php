<?php // “ If you can't take the heat, don't tickle the dragon. ”
