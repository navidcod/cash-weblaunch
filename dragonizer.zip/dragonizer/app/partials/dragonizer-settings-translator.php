<?php

// If user not in admin area, abort.
defined('DRAGONIZER_ADMIN_INIT') || die();

function display_translator($obj)
{

    $dragonizer_allowed_description_tags = array(
        'br'   => array(),
        'span' => array(
            'style' => array(),
        ),
    );

?>
    <input type="hidden" name="dragonizer_settings[translator]" value="">

    <script>
        "use strict";
        jQuery(document).ready(function(a) {
            var e = /[,\\\/\#\)\(\<\>\'\"\`]/g;

            function o(t, n) {
                return n ? '<input name="dragonizer_settings[translator][{_index_}][text]" type="text"\n class="large-text form-control '.concat(t.toLowerCase(), '" placeholder="').concat(t, '" />') : '<input name="dragonizer_settings[translator][{_index_}][replace]" type="text"\n class="large-text form-control '.concat(t.toLowerCase(), '" placeholder="').concat(t, '" />')
            }

            function r() {
                var n = 0;
                a(".form-control").each(function() {
                    var t = a(this).attr("name");
                    a(this).attr("name", t.replace("{_index_}", n)), -1 !== t.indexOf("replace") && n++
                })
            }
            a("input").on("input", function() {
                var t = this.selectionStart,
                    n = a(this).val();
                e.test(n) && (a(this).val(n.replace(e, "")), t--), this.setSelectionRange(t, t)
            }), a("#add").on("click", function() {
                var t, n, e = 0;
                a("#fields tr").each(function() {
                    return a(this).find("input").each(function() {
                        "" == a.trim(a(this).val()) && e++
                    }), !(2 <= e) && void(e = 0)
                }), e < 2 && (t = "\n<tr>\n <td>".concat(o("<?= __('Text', 'dragonizer') ?>", !0), "</td>\n <td>").concat(o("<?= __('Replace', 'dragonizer') ?>", !1), '</td>\n <td style="width: 1vw;"><button id="del" type="button" class="button remove"><span class="dashicons dashicons-trash"></span></button></td>\n</tr>\n'), n = a("#fields tbody"), a(t).appendTo(n), r())
            }), a("#fields").on("click", "tbody tr .remove", function(t) {
                a(this).parents("tr").remove()
            }), r()
        });
    </script>

    <h3 class="dragon-hidden"><?php esc_html_e('Translate or replace site words', 'dragonizer'); ?> <span class="dragonizer_security_badge dragonizer_safe_badge"><?php esc_html_e('Completely safe', 'dragonizer'); ?></span></h3>

    <p class="dragon-hidden"><?php esc_html_e('With the help of this section, you can (replace) all common, long or dynamic text in your site. (Words that have already been translated are not recognized)', 'dragonizer'); ?></p>

    <table class="dragon-hidden" id="fields" class="traslator">
        <tbody>
            <?php

            if (empty($obj->settings['translator']) || count($obj->settings['translator']) === 0) { ?>
                <tr>
                    <td> <input name="dragonizer_settings[translator][{_index_}][text]" type="text" class="large-text form-control key" placeholder="<?= __('Text', 'dragonizer') ?>"> </td>
                    <td> <input name="dragonizer_settings[translator][{_index_}][replace]" type="text" class="large-text form-control value" placeholder="<?= __('Replace', 'dragonizer') ?>" /> </td>
                    <td> <button id="del" type="button" class="button remove"> <span class="dashicons dashicons-trash"></span> </button> </td>
                </tr>
                <?php } else {

                foreach ($obj->settings['translator'] as $index => $value) { ?>
                    <tr>
                        <td> <input name="dragonizer_settings[translator][<?= $index ?>][text]" type="text" class="large-text form-control key" value="<?= $value['text'] ?>"> </td>
                        <td> <input name="dragonizer_settings[translator][<?= $index ?>][replace]" type="text" class="large-text form-control value" value="<?= $value['replace'] ?>" /> </td>
                        <td> <button id="del" type="button" class="button remove"> <span class="dashicons dashicons-trash"></span> </button> </td>
                    </tr>
            <?php }
            } ?>

        </tbody>
    </table>
    <br>


    <p class="dragon-hidden">
        <button id="add" type="button" class="button add-row">
            <span class="dashicons dashicons-plus"></span>
        </button>
    </p>

    <br><br>
    <p style="margin-bottom:200px" class="dragon-hidden"><?php wp_kses(_e('<span style="color: #d94f4f">Notice: </span>Reload the page after saving changes to see the results!', 'dragonizer'), $dragonizer_allowed_description_tags); ?></p>

<?php
}
