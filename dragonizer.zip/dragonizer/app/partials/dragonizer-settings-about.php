<?php

// If user not in admin area, abort.
defined('DRAGONIZER_ADMIN_INIT') || die();

function display_about($obj)
{
    $html = '<div style="line-height:2;white-space: pre-line;text-align:justify">' . __('We’re thrilled to have you as part of the <span style="color:#9d0110; font-weight:700">Dragonizer</span> family! We truly hope you find this plugin helpful and enjoy its features.<br><br>Creating, coding, testing, and refining <span style="color:#9d0110; font-weight:700">Dragonizer</span> has taken over <span style="font-weight:700">2,000 hours</span> of dedicated work so far. If you’re finding it valuable and recognize the effort that has gone into making it, we’d be grateful if you could spare just 2 minutes to rate the plugin on rtl-theme.com. Your feedback helps keep our development alive and moving forward!<br><br>We’ve built <span style="color:#9d0110; font-weight:700">Dragonizer</span> with great attention to detail, but this is just the beginning of our journey. If you notice any issues, please <span style="color:#0fa327; font-weight:700">let us know</span>. We’re committed to fixing reported bugs quickly and taking your suggestions into account for future updates.<br><br>Thank you for choosing <span style="color:#9d0110; font-weight:700">Dragonizer</span>. We’re excited to support you and your WordPress journey. Wishing you continued success :)', 'dragonizer') . '</div><br>';

?>
    <p class="dragon-hidden"><?php echo $html ?></p>

<?php
}
