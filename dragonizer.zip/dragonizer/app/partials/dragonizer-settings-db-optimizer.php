<?php

// If user not in admin area, abort.
defined('DRAGONIZER_ADMIN_INIT') || die();

function display_db_optimizer($obj)
{
	// $db_class = new Dragonizer_Database($obj->database);
	// $db_class->generate_all_database_fileds();

	$db_class = Dragonizer_Database::getInstance($obj->database);
	$db_class->generate_all_database_fileds();
}
